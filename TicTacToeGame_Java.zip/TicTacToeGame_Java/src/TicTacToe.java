public class TicTacToe {

    public static void Main(String args[]){

        char[][] board = {{' ',' ',' '},
                          {' ',' ',' '},
                          {' ',' ',' '}};

        System.out.println(board[0][0]);
    }
}
